package logic;


public class Calculator {
	
	public int sum(int a, int b) {
		return(a+b);
	}
	
	public int substraction(int a, int b) {
		return(a-b);
	}
	
	public int multiplication(int a, int b) {
		return(a*b);
	}
	
	public int division(int a, int b) {
		return(a/b);
	}
}